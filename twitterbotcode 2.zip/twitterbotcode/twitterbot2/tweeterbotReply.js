


///// RUNNING ///// RUNNING ///// RUNNING ////

console.log('twitterbotREPLY.js is running...hopefully running smoothly ');
//installed and using package.json called "Twit package"
//package.json is a file with other dependencies in json formati

var Twit = require ('twit'); //import statement to use this package/library called Twit

//we need to authenticate - these are secret code values tied to the twitter account that are associated with this particular node app
//you can find them in the config.js
var config = require('./config'); // we reuire the keys in the config.js file
var T = new Twit(config);

///// RUNNING ///// RUNNING ///// RUNNING /////





///// TWEETS ///// TWEETS ///// TWEETS  ///// TWEETS ///// TWEETS /////
///// TWEETS ///// TWEETS ///// TWEETS  ///// TWEETS ///// TWEETS /////
///// TWEETS ///// TWEETS ///// TWEETS  ///// TWEETS ///// TWEETS /////

var tweetListArray = ["something just destroyed 102,916 trees on my body #SOS ", 
"I'm coming down with a case of Global Warming, Doc said my temp is too high #omg", 
"I think im allergic to plastic, I just ate 4,000 plsatic bags in australia in the past minute #Foodie", 
"I feel like I'm missing some species, I could have sworn I had 200 more yesterday #Extinction #GlobalWarming", 
"I just gained 2.4 million pounds of CO2, the gym won't help me solve this issue #GreenHouseGases ",
"starving me of 55 square feet of rainforest so you can eat one meal with meat #Thanks #backstabbingbetch", 
"14,400 acres of rainforest were lost yesterday, like where are they even going? #CattleFarming",
"This guy called greenhouse keeps farting and I think I’m actually suffocating here #SOS #Pollution #ClimateChange",
"So not looking forward to next summer - I see deadly sun strokes in my future #SadButTrue #ClimateChange",
"Guess what witches & I have in common?! We’re both melting! except witches melt from water & I’m turning into water so…",
"My fortune cookie told me I have 5,000 years until I’m totally melted @Neptune we should chill out sometime #Melting",
"my mom is so insane she causes like 90% of all my natural disasters @MotherNature #CalmDown #Omg #ClimateChange",
"Low key I think the #GreatBarrierReef hates me cause it keeps disappearing on me #ClimateChange ",
"#TB to me chilling with the @GreatBarrierReef #GoodTimes",
"I think im allergic to plastic, I just ate 4,000 plastic bags in Australia in the past minute #Foodie",
"I just gained 2.4 million pounds of CO2, the gym won't help me solve this issue #GreenHouseGases",
"something just destroyed 102,916 trees on my body- I’m gonna let my lawyer know about this @EarthJustice #SOS",
"I feel like im missing some species #Extinction #GlobalWarming",
"I’m coming down with a case of Global Warming, Doc said my temp is too high #omg",
];

///// TWEETS ///// TWEETS ///// TWEETS  ///// TWEETS ///// TWEETS /////
///// TWEETS ///// TWEETS ///// TWEETS  ///// TWEETS ///// TWEETS /////
///// TWEETS ///// TWEETS ///// TWEETS  ///// TWEETS ///// TWEETS /////




///////// FUNCTIONS AND INTERVALS /////////
///////// FUNCTIONS AND INTERVALS /////////


setInterval(tweetItStatus,1000*60) //1000mili=1sec 1000*10=10sec

tweetItStatus(); //calling status tweet function

tweetItReply(); //calling reply tweet function 

///////// FUNCTIONS AND INTERVALS /////////
///////// FUNCTIONS AND INTERVALS /////////






////// USER STREAM REPLY ////// USER STREAM REPLY //////
////// USER STREAM REPLY ////// USER STREAM REPLY //////
////// USER STREAM REPLY ////// USER STREAM REPLY //////

//setting up a user stream
var stream = T.stream('user');
//anytime someone follows me (could be 'favourite', 'tweet', 'retweet')
stream.on('follow', followed); //if someone follows me, carry out followed(); funtion

function followed(eventMsg){ //code deals with follow event for this stream 
	console.log("!!!SOMEONE FOLLOWED YOU!!!");
 	var name = eventMsg.source.name; //taking data from JSON of other user
 	var screenName = eventMsg.source.screen_name; //taking from JSON
 	tweetItReply( ' @' + screenName + ' thanks for the follow fellow #EarthLing');
} 


function tweetItReply(txt){
		var r = Math.floor(Math.random()*100);

		var tweetReply = { //tweet Reply from EarthLing account
			status: txt + r
		}

		T.post('statuses/update', tweetReply, tweetedReply);


		function tweetedReply (err, data, response){ //callbackfunction DID IT WORK OR NOT?
			if(err){
				console.log(data);
			} else {
			console.log("TWEET REPLY POSTED #SUCCESS");
			}
		}
}


////// USER STREAM REPLY ////// USER STREAM REPLY //////
////// USER STREAM REPLY ////// USER STREAM REPLY //////
////// USER STREAM REPLY ////// USER STREAM REPLY //////






///// TWEET STATUS ///// TWEET STATUS ///// TWEET STATUS /////
///// TWEET STATUS ///// TWEET STATUS ///// TWEET STATUS /////
///// TWEET STATUS ///// TWEET STATUS ///// TWEET STATUS /////

var index = 0; //this number will increase for every tweet, 
//thus dictating the item from the array we will be tweeting

function tweetItStatus(){

	var r = Math.floor(Math.random()*100);

		var tweetStatus = { //tweet from EarthLing account
			//status: ' #EarthLing is on twitter everyone! #EARTH ' + r
			status: tweetListArray[index] + ' ' + r
		}


		// path: status/update 
		//object that will have info for that status update: tweet
		//call back: tweeted
		T.post('statuses/update', tweetStatus, tweetedStatus);


		function tweetedStatus (err, data, response){ //callbackfunction DID IT WORK OR NOT?
			if(err){
				console.log("TWEET STATUS DIDNT POST #ERROR");
			} else {
				index++;
			console.log("TWEET STATUS POSTED #SUCCESS");
			}
		}
}

///// TWEET STATUS ///// TWEET STATUS ///// TWEET STATUS /////
///// TWEET STATUS ///// TWEET STATUS ///// TWEET STATUS /////
///// TWEET STATUS ///// TWEET STATUS ///// TWEET STATUS /////












////// SEARCHING TWEETS /////// SEARCHING TWEETS /////////// SEARCHING TWEETS ///////
////// SEARCHING TWEETS /////// SEARCHING TWEETS /////////// SEARCHING TWEETS ///////
////// SEARCHING TWEETS /////// SEARCHING TWEETS /////////// SEARCHING TWEETS ///////

//information on what to search for 
//object with parameters
var paramsRenewable = {
	q: ('#renewableenergy', 'renewable energy'),//queery term  500 characters maximum
	count:1
}
var paramsSolar = {
	q: '#SolarEnergy',//queery term  500 characters maximum
	count:1
}
var paramsWind = {
	q: '#WindPower',//queery term  500 characters maximum
	count:1
}
var paramsNuclear = {
	q: '#NuclearEnergy',//queery term  500 characters maximum
	count:1
}
var paramsRock = {
	q: '#StandingRock',//queery term  500 characters maximum
	count:1
}

var paramsSustainable = {
	q: '#Sustainable',//queery term  500 characters maximum
	count:1
}
var paramsClimate = {
	q: '#ClimateChange',//queery term  500 characters maximum
	count:1
}

//asking twitter to search for tweets
//search twitter
T.get('search/tweets', paramsRenewable, gotData);
T.get('search/tweets', paramsSolar, gotData);
T.get('search/tweets', paramsWind, gotData);
T.get('search/tweets', paramsNuclear, gotData);
T.get('search/tweets', paramsRock, gotData);
T.get('search/tweets', paramsSustainable, gotData);
T.get('search/tweets', paramsClimate, gotData);
//call back function that will be
// triggered when we have collected 
//data from the twitter API
// T.post is making a status update 
function gotData(err, data, response){
	var tweets = data.statuses; //only pulling out tweet, not all info
	for (var i= 0; i< tweets.length; i++){
		console.log(tweets[i].text) //console log the found tweet in terminal
	}
}
////// SEARCHING TWEETS /////// SEARCHING TWEETS /////////// SEARCHING TWEETS ///////
////// SEARCHING TWEETS /////// SEARCHING TWEETS /////////// SEARCHING TWEETS ///////
////// SEARCHING TWEETS /////// SEARCHING TWEETS /////////// SEARCHING TWEETS ///////







//get() request search by hashtag, location, by user, give me 100 tweets 
//post() this is tweeting, post tweets 
//stream() be connected to twitter API, assign events to the stream. so if someone tweets me, it automatically tweets back


