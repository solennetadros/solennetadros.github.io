module.exports = {
  consumer_key:         'aiDytXZwQ1L6VjsgZ5U1IMCYA',
  consumer_secret:      '0O8SB6KmEmrr67ZYhGuQaBrbeDeVBBF7S2QXHHtTw5CfNuviw4',
  access_token:         '809245376184254464-Tw8a5Cu3tvXwBUkIkfv48hbbexXLaY2',
  access_token_secret:  '6Mlu6Rp2GO6mtfGrBo2WDiEz2fPoKg7FWBnmiwDFU9oXv',
}